export const environment = {
  production: true,
  usersUrl:'http://localhost:8081/oms'
};
