import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-widget-welcomeadmin',
  templateUrl: './welcomeadmin.component.html',
  styleUrls: ['./welcomeadmin.component.scss']
})
export class WelcomeadminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
