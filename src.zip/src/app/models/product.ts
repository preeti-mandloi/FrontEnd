export interface Product {
    
        name:string,
        quantity:number,
        type:string,
        price:number,
        mfg:string,
        exp:string,
        
}
export interface Order{
        name:string,
        quantity:number,
        price:number,
        totalPrice:number
}
